# Step 8 — External validation evidence

## Data sources
- CICIoT2023: attack prevalence 97.666%.
- ToN-IoT Network: 211,043 records; attack prevalence 76.308%.
- HITL-IoT v1.1: 127,845 records; attack prevalence 15.000%.

## Protocol
- HITL-IoT uses the frozen temporal train/validation/test partition.
- External datasets use fixed-seed stratified 70/15/15 internal partitions.
- Cross-domain thresholds are selected on source validation only.
- Primary transfer uses the same conservative universal feature map in all three domains.
- Duplicate-sensitive in-domain results are repeated on development-novel test rows whose exact harmonized feature vector appears in neither training nor validation.

## Random-Forest transfer summary
- HITL-IoT → HITL-IoT: Macro-F1=0.7703, MCC=0.5634, AUROC=0.8229.
- HITL-IoT → CICIoT2023: Macro-F1=0.1071, MCC=-0.1608, AUROC=0.2949.
- HITL-IoT → ToN-IoT: Macro-F1=0.2593, MCC=-0.1365, AUROC=0.6285.
- CICIoT2023 → HITL-IoT: Macro-F1=0.4416, MCC=-0.0126, AUROC=0.4788.
- CICIoT2023 → CICIoT2023: Macro-F1=0.8999, MCC=0.8076, AUROC=0.9967.
- CICIoT2023 → ToN-IoT: Macro-F1=0.4376, MCC=-0.0666, AUROC=0.7451.
- ToN-IoT → HITL-IoT: Macro-F1=0.3462, MCC=-0.0169, AUROC=0.4279.
- ToN-IoT → CICIoT2023: Macro-F1=0.4450, MCC=-0.0257, AUROC=0.4293.
- ToN-IoT → ToN-IoT: Macro-F1=0.9877, MCC=0.9753, AUROC=0.9983.

## Duplicate-leakage robustness
- HITL-IoT: 0.0% of rows share a harmonized feature vector; 0.0% of test vectors also occur in training and 0.0% occur in training/validation.
- CICIoT2023: 52.6% of rows share a harmonized feature vector; 52.5% of test vectors also occur in training and 52.6% occur in training/validation.
- ToN-IoT: 60.7% of rows share a harmonized feature vector; 59.7% of test vectors also occur in training and 60.3% occur in training/validation.
- HITL-IoT in-domain RF on development-novel test rows (n=19,177): Macro-F1=0.7703, MCC=0.5634.
- CICIoT2023 in-domain RF on development-novel test rows (n=74,538): Macro-F1=0.8969, MCC=0.8020.
- ToN-IoT in-domain RF on development-novel test rows (n=12,573): Macro-F1=0.9795, MCC=0.9592.

## Domain separability
- HITL-IoT vs CICIoT2023: exact-vector-deduplicated domain-discriminator AUROC 0.986 (logistic) and 1.000 (random forest).
- HITL-IoT vs ToN-IoT: exact-vector-deduplicated domain-discriminator AUROC 0.947 (logistic) and 0.995 (random forest).
- HITL-IoT ttl is a per-device constant by design and is excluded from every model.
- ToN-IoT chronological sensitivity was not run because the supplied network file contains no usable timestamp field.

## Selective-prediction duplicate robustness
- HITL-IoT: validation-selected calibrated uncertainty captured 35.7% of RF errors on all test, 35.7% of RF errors on development-novel test at an exact 8% review budget.
- CICIoT2023: validation-selected calibrated uncertainty captured 100.0% of RF errors on all test, 98.8% of RF errors on development-novel test at an exact 8% review budget.
- ToN-IoT: validation-selected calibrated uncertainty captured 90.8% of RF errors on all test, 87.8% of RF errors on development-novel test at an exact 8% review budget.

## Interpretation boundary
These experiments quantify distributional correspondence, domain shift, transfer utility, calibration, and selective-prediction portability. They do not establish empirical human-behaviour validity, operational SOC performance, or one-to-one equivalence between synthetic and capture-derived features.