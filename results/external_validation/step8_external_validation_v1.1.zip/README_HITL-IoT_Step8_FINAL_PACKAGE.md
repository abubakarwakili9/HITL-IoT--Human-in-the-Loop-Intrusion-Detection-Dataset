# HITL-IoT Step 8 — Final External-Validation Delivery

Executed on the real supplied external CSVs and the canonical frozen HITL-IoT v1.1 release.

## Contents
- clean final notebook
- executed final notebook (30/30 code cells, no errors)
- complete Step-8 output tree
- Figures 13–15 in PDF/SVG/600-dpi PNG
- distribution, transfer, calibration, selective-prediction and AURC tables
- duplicate-leakage and final audit files
- manuscript-ready external-validation evidence
- full package additionally includes the three serialized RF reference models

## Packages
- `HITL-IoT_Step8_FINAL_Results_Compact.zip`: excludes large `.joblib` models.
- `HITL-IoT_Step8_FINAL_Full_Reproducibility.zip`: includes models.

See `STEP8_FINAL_RESULTS_SUMMARY.md` for interpretation caveats.


## CICIoT2023 naming convention
All manuscript-facing figures, captions, tables, and summaries use the canonical name **CICIoT2023**. The source file is `IoT_Intrusion.csv` from the referenced IoT Intrusion Detection dataset page; file-level row count and SHA-256 are retained only in audit/provenance outputs.
