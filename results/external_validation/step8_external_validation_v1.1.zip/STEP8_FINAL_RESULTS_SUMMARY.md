# HITL-IoT v1.1 — Step 8 External Validation: Final Real-Data Results

**Execution status:** COMPLETE. The final notebook executed all 30 code cells with no errors on CICIoT2023, the ToN-IoT Network dataset, the canonical HITL-IoT v1.1 release, and the frozen Step-6 benchmark.

## Integrity and provenance

- Canonical HITL-IoT dataset SHA-256 verified: `c6dd623029f6ca0967773379b2afbba96b73ab9cb2028c5e81ef89a1b15e1291`.
- Frozen Step-6 scientific invariants verified; all-nine probability handoff and Random-Forest reference selection verified.
- **CICIoT2023** is used consistently as the external IoT benchmark name. The exact local `IoT_Intrusion.csv` filename and SHA-256 remain in audit outputs for reproducibility.
- ToN-IoT Network contains 211,043 records. The supplied file has no usable timestamp, so chronological ToN sensitivity is explicitly recorded as unavailable.
- Final audit: **24/24 PASS**.
- Figures 13–15 passed automated publication-quality QC.
- All three serialized Random-Forest reference pipelines were fresh-process load tested successfully.

## External domain gap

- HITL-IoT vs CICIoT2023: deduplicated domain-discriminator AUROC = **0.986** (logistic) and **1.000** (Random Forest).
- HITL-IoT vs ToN-IoT: deduplicated domain-discriminator AUROC = **0.947** (logistic) and **0.995** (Random Forest).

These values indicate strong residual separation between HITL-IoT and both capture/testbed external domains after conservative feature harmonization. This should be reported as a **domain gap**, not hidden or converted into a realism score.

## Cross-domain Random-Forest transfer

- HITL-IoT → HITL-IoT: Macro-F1 **0.770**, MCC **0.563**, AUROC **0.823**.
- HITL-IoT → CICIoT2023: Macro-F1 **0.107**, MCC **-0.161**, AUROC **0.295**.
- HITL-IoT → ToN-IoT: Macro-F1 **0.259**, MCC **-0.137**, AUROC **0.628**.
- CICIoT2023 → HITL-IoT: Macro-F1 **0.442**, MCC **-0.013**, AUROC **0.479**.
- CICIoT2023 → CICIoT2023: Macro-F1 **0.900**, MCC **0.808**, AUROC **0.997**.
- CICIoT2023 → ToN-IoT: Macro-F1 **0.438**, MCC **-0.067**, AUROC **0.745**.
- ToN-IoT → HITL-IoT: Macro-F1 **0.346**, MCC **-0.017**, AUROC **0.428**.
- ToN-IoT → CICIoT2023: Macro-F1 **0.445**, MCC **-0.026**, AUROC **0.429**.
- ToN-IoT → ToN-IoT: Macro-F1 **0.988**, MCC **0.975**, AUROC **0.998**.

Cross-domain Macro-F1 is substantially lower than within-domain performance, providing independent evidence that the datasets are not interchangeable and that HITL-IoT should complement rather than replace capture-based benchmarks.

## Duplicate-vector robustness

- HITL-IoT: 0.0% of rows occur in duplicated universal-feature vectors; 0.0% of test vectors also occur in train/validation; strict development-novel test n=19,177.
- CICIoT2023: 52.6% of rows occur in duplicated universal-feature vectors; 52.6% of test vectors also occur in train/validation; strict development-novel test n=74,538.
- ToN-IoT: 60.7% of rows occur in duplicated universal-feature vectors; 60.3% of test vectors also occur in train/validation; strict development-novel test n=12,573.
- HITL-IoT in-domain RF on development-novel test: Macro-F1 **0.770**, MCC **0.563** (n=19,177).
- CICIoT2023 in-domain RF on development-novel test: Macro-F1 **0.897**, MCC **0.802** (n=74,538).
- ToN-IoT in-domain RF on development-novel test: Macro-F1 **0.979**, MCC **0.959** (n=12,573).

## Calibration

- HITL-IoT: validation-selected **isotonic** calibration changed ECE from **0.1740** to **0.0071** and Brier score from **0.1197** to **0.0769**.
- CICIoT2023: validation-selected **platt** calibration changed ECE from **0.0142** to **0.0010** and Brier score from **0.0125** to **0.0069**.
- ToN-IoT: validation-selected **isotonic** calibration changed ECE from **0.0173** to **0.0019** and Brier score from **0.0091** to **0.0076**.

## Selective prediction at the predeclared 8% review budget

- CICIoT2023, all test: calibrated uncertainty captured **100.0%** of RF errors; retained risk **0.00%**; retained classes **1**; retained attack rate **100.00%**; retained MCC **undefined**.
- CICIoT2023, development-novel test: calibrated uncertainty captured **98.8%** of RF errors; retained risk **0.04%**; retained classes **2**; retained attack rate **99.99%**; retained MCC **0.142**.
- HITL-IoT, all test: calibrated uncertainty captured **35.7%** of RF errors; retained risk **10.16%**; retained classes **2**; retained attack rate **13.05%**; retained MCC **0.521**.
- HITL-IoT, development-novel test: calibrated uncertainty captured **35.7%** of RF errors; retained risk **10.16%**; retained classes **2**; retained attack rate **13.05%**; retained MCC **0.521**.
- ToN-IoT, all test: calibrated uncertainty captured **90.8%** of RF errors; retained risk **0.10%**; retained classes **2**; retained attack rate **80.15%**; retained MCC **0.997**.
- ToN-IoT, development-novel test: calibrated uncertainty captured **87.8%** of RF errors; retained risk **0.24%**; retained classes **2**; retained attack rate **76.08%**; retained MCC **0.993**.

**Important CICIoT2023 caveat:** on the full CIC test set, 8% uncertainty review removes all observed RF errors but leaves a one-class retained set (100% attack), so accuracy/Macro-F1 alone would be misleading; MCC is correctly undefined. The strict development-novel subset remains two-class and is the more informative robustness check.

## Interpretation for Reviewer 3

The external experiments provide the requested independent evidence, but they do **not** validate empirical human behaviour. The strongest defensible conclusion is that HITL-IoT supports controlled oversight-mechanism studies while exhibiting a measurable domain gap relative to CICIoT2023 and ToN-IoT. AI-side calibration and selective-prediction mechanisms remain measurable on external traffic, but their benefits are domain- and class-distribution-dependent.

The manuscript should avoid claiming that HITL-IoT is a drop-in surrogate for real/capture-based traffic or that external traffic validation establishes real-analyst validity.