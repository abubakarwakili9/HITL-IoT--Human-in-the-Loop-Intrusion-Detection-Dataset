# Reviewer 3 — Track-1 experimental evidence (factual; not the rebuttal letter)

- **All nine reviewed model families retained:** Logistic Regression, SVM (RBF), Random Forest, XGBoost, LightGBM, MLP, 1D-CNN, LSTM, Voting Ensemble — continuity audit status PASS for every family.
- **Construction signals excluded:** generated_attack_score, generated_prediction, ambiguity_score, all oversight fields, labels and identifiers are excluded by a programmatic leakage audit (all checks PASS).
- **Chronological evaluation:** temporal 70/15/15 with strict timestamp boundaries is the primary protocol; hyperparameters and the Step-7 reference model were selected on validation only; each test partition was evaluated once per model after selection.
- **IID sensitivity:** all nine models re-run on the IID 70/15/15 split; macro-F1 differences (IID − temporal) -0.0001 to +0.0075.
- **Independent probabilities:** raw held-out probabilities for all nine models (validation and test, both protocols) are released; none is derived from generator scores.
- **Strengthened shortcut audit:** one-feature logistic models for all 39 features (validation only); maximum direction-adjusted AUROC 0.7919 (service_category). Near-deterministic category levels are reported with their training coverage.
- **Service/port ablation:** removing service/port context changes macro-F1 by -0.0456 to -0.0445 for the representative tree models.
- **Subgroup analysis:** attack-family (12 families × 9 models) and device-level (5 devices × 9 models) performance tables are provided.
- **Replacement of legacy evidence:** the near-perfect v1.0 full-feature values (accuracy 0.9781–0.9960) are replaced as principal evidence by leakage-safe temporal results (accuracy 0.9653–0.9849); the legacy values are kept only in a traceability table.
- **LSTM correction (documented):** the exact legacy LSTM and a stabilised variant (gradient clipping, ±5 SD input capping) both stayed at the prevalence-baseline validation loss under the legacy 75-step sequence framing; the reported LSTM keeps the legacy layers and settings but presents each flow as a single time step (1 × 75). Decisions used train/validation evidence only; both failed learning curves are released in the audit folder.
- **Continuity note on configurations:** legacy 1D-CNN/LSTM architectures and the ensemble composition were recovered exactly; the manuscript's stated XGBoost/LightGBM settings disagree with the legacy notebook and must be corrected in the text.
