# Manuscript synchronisation checklist (do not edit the DOCX until results are frozen)

Legacy items in the reviewed manuscript that must be updated from the frozen v1.1 artefacts:

- [ ] v1.0 terminology: ml_confidence, ml_prediction, risk_score, human_reviewed, human_decision, human_confidence, decision_time, ml_human_agreement, annotator_id → v1.1 names (see variable audit of Notebook 02).
- [ ] Old device percentages (Table 2; "Mixed/Unknown") → Notebook 02 device_distribution.csv.
- [ ] Unsupported application-protocol realism (MQTT/CoAP/RTSP/DLNA emulation) → "service/port categories"; transport protocol is TCP/UDP only.
- [ ] Old configured profile accuracies (α = 0.92/0.85/0.75) → configured-profile parameters and observed balanced accuracies (Notebook 02 Table 4).
- [ ] Old file name HITL-IoT_human_annotations.csv → HITL-IoT_oversight_subset_v1.1.csv.
- [ ] Old 80/20 stratified split (102,276/25,569) → temporal 70/15/15 (primary) and IID 70/15/15 (secondary).
- [ ] Old full-feature nine-model Table 7 → Table7_Track1_Temporal_All9_Baselines.csv; legacy values only in the traceability table.
- [ ] "Inference latency (ms/sample)" → "amortized batch inference time (ms/sample)"; single-record timing in the supplement.
- [ ] Model settings paragraph: legacy notebook XGBoost max_depth=10 and LightGBM lr=0.1, n_estimators=100 contradict the manuscript text (max_depth=6; lr=0.05, n_estimators=150); replace with the selected v1.1 configurations (selected_hyperparameters_all9.csv).
- [ ] "Neural models tuned over layer sizes, dropout rates and epochs" → fixed legacy architectures with validation early stopping; state the LSTM correction (gradient clipping, ±5 SD input capping, single-time-step input) and why, citing the two failed learning curves.
- [ ] Old Figures 7–9 (diagnostic full-feature) → new Figures 7–9 of this notebook.
- [ ] Section 5.3 "subgroup analysis not reported" → attack-family and device tables now available.
- [ ] Old oversight-profile counts, disagreement and calibration numbers → Notebook 02 outputs (Step 7 will replace the oversight experiments).
- [ ] Remove any "no temporal drift" wording; use "evaluation-protocol sensitivity" and the chronological-holdout statement.
