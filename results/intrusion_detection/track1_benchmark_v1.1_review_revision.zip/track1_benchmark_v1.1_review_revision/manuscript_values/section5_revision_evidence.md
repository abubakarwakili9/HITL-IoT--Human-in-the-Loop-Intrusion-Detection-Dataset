# Section 5 revision evidence (generated from results)

The original submission evaluated nine model families under an 80/20 stratified hold-out and broader diagnostic feature configuration. The revision retains all nine model families but reevaluates them under the frozen HITL-IoT v1.1 `track1_primary_flow_only` policy (39 source features, 75 encoded inputs) and a chronological 70/15/15 train/validation/test protocol. Generated construction signals, oversight metadata, identifiers and target labels are excluded from all model inputs. The revised scores therefore provide a more conservative leakage-safe reference benchmark while preserving continuity with the original reviewed experiment.

On the temporal test partition (n = 19,177), accuracy ranged from 0.9653 (Logistic Regression) to 0.9849 (Random Forest), balanced accuracy from 0.8839 to 0.9491, macro-F1 from 0.9239 to 0.9688, MCC from 0.8577 to 0.9395 and AUROC from 0.9415 to 0.9703. False-positive rates ranged from 0.000% to 0.692% and false-negative rates from 10.18% to 23.18%. Under the secondary IID protocol, macro-F1 differed from the temporal value by -0.0001 to +0.0075.

1. Accuracy on the temporal test partition ranges from 0.9653 (Logistic Regression) to 0.9849 (Random Forest) across the nine models.
2. Macro-F1 ranges from 0.9239 (Logistic Regression) to 0.9688 (Random Forest).
3. MCC ranges from 0.8577 (Logistic Regression) to 0.9395 (Random Forest); AUROC from 0.9415 to 0.9703.
4. IID − temporal macro-F1 differences range from -0.0001 to +0.0075 (evaluation-protocol sensitivity). Class prevalence remains broadly stable across the generated period, while the temporal protocol enforces chronological separation; the generator was not designed to impose a systematic concept or covariate shift, so the temporal experiment evaluates chronological holdout performance rather than robustness to deliberately induced temporal drift.
5. Lowest mean recall among the representative tree models: credential_harvesting (0.677), protocol_abuse (0.745), configuration_tampering (0.770). Most missed attacks summed over all nine models: botnet_communication (545), protocol_abuse (533), network_mapping (440).
6. Highest mean attack FNR among the representative tree models by device: speaker (12.60%), doorbell (10.82%), tv (10.34%); lowest: camera (8.33%).
7. Removing service_category changes macro-F1 by -0.0002 to +0.0000; removing all service/port context changes it by -0.0456 to -0.0445 (representative tree models, no retuning). Service/port context is therefore an important contributor to separability.
8. The highest single-feature validation AUROC is 0.7919 (service_category); no individual Track-1 feature reaches 0.95.
9. Step-7 reference classifier (temporal validation only; macro-F1 → MCC → AUROC): Random Forest (validation macro-F1 0.9677).
10. Relative to the legacy full-feature diagnostic Table 7, accuracy is lower by 0.0077 to 0.0128 across models. Performance decreases modestly under the more conservative evaluation design while remaining strong across independent classifiers; the two settings differ in data version, feature policy and split, so the values are not directly comparable.
