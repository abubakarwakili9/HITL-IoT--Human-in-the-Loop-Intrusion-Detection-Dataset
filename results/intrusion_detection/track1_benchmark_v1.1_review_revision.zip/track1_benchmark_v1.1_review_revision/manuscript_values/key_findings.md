# Key findings (generated)

1. Accuracy on the temporal test partition ranges from 0.9653 (Logistic Regression) to 0.9849 (Random Forest) across the nine models.

2. Macro-F1 ranges from 0.9239 (Logistic Regression) to 0.9688 (Random Forest).

3. MCC ranges from 0.8577 (Logistic Regression) to 0.9395 (Random Forest); AUROC from 0.9415 to 0.9703.

4. IID − temporal macro-F1 differences range from -0.0001 to +0.0075 (evaluation-protocol sensitivity). Class prevalence remains broadly stable across the generated period, while the temporal protocol enforces chronological separation; the generator was not designed to impose a systematic concept or covariate shift, so the temporal experiment evaluates chronological holdout performance rather than robustness to deliberately induced temporal drift.

5. Lowest mean recall among the representative tree models: credential_harvesting (0.677), protocol_abuse (0.745), configuration_tampering (0.770). Most missed attacks summed over all nine models: botnet_communication (545), protocol_abuse (533), network_mapping (440).

6. Highest mean attack FNR among the representative tree models by device: speaker (12.60%), doorbell (10.82%), tv (10.34%); lowest: camera (8.33%).

7. Removing service_category changes macro-F1 by -0.0002 to +0.0000; removing all service/port context changes it by -0.0456 to -0.0445 (representative tree models, no retuning). Service/port context is therefore an important contributor to separability.

8. The highest single-feature validation AUROC is 0.7919 (service_category); no individual Track-1 feature reaches 0.95.

9. Step-7 reference classifier (temporal validation only; macro-F1 → MCC → AUROC): Random Forest (validation macro-F1 0.9677).

10. Relative to the legacy full-feature diagnostic Table 7, accuracy is lower by 0.0077 to 0.0128 across models. Performance decreases modestly under the more conservative evaluation design while remaining strong across independent classifiers; the two settings differ in data version, feature policy and split, so the values are not directly comparable.