Oversight reachability: the review-eligible pool holds 1,541 of 19,177 temporal-test decisions (8.04%), but only 14 of 289 classifier errors fall inside it (4.8%). At most 7 decisions are correctable by the configured profile (0.037% of all decisions), while 293 correct decisions are exposed to harm; inside the pool the classifier is correct on 0.991 of flows against 0.805 for the configured profiles. Every override result below is bounded by this ceiling.
Generator ambiguity and model uncertainty are largely distinct: model uncertainty identifies pool membership with AUROC 0.503 and Spearman correlation 0.053; only 11.9% of the 8% most model-uncertain flows lie in the ambiguity pool. Oversight headroom in HITL-IoT v1.1 is therefore a property of how the review pool was constructed, not a limitation of the routing signal.
# Reviewer-facing Step 7 evidence

## What was added

1. Independent probability calibration of the frozen validation-selected Random Forest.
2. Selective-prediction/reject-option evaluation at fixed review budgets.
3. Matched-budget random-routing baseline.
4. Human-AI collaboration experiments on the canonical 8% oversight pool.
5. Explicit accounting of AI errors corrected and correct AI decisions harmed.
6. Confidence-gated profile override selected on temporal validation only.
7. Learned deferral utility baseline using out-of-bag training probabilities (when enabled).
8. Secondary IID sensitivity analysis.
9. No use of `generated_attack_score` as the Step-7 AI confidence signal.

## Interpretation boundary

The configured oversight profiles are generated benchmark variables. Therefore these results demonstrate that HITL-IoT can support controlled and reproducible comparison of candidate collaboration and oversight mechanisms. They do not establish empirical analyst behaviour, operational SOC effectiveness, professional competence, or legal compliance.

## Test-set isolation

No calibration model, confidence gate, review-budget threshold, or learned defer model is fitted or selected using temporal-test labels.