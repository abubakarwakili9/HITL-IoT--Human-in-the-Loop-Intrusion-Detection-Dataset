# Step 7 manuscript-ready evidence

The frozen Step-6 Random Forest was retained as the Step-7 reference classifier because it was selected using temporal validation only (validation Macro-F1 0.9677).

Calibration models were fitted only on the first chronological half of temporal validation, while calibration-method selection and policy thresholds were determined on the second half. The untouched temporal test set was used only for final evaluation.

On temporal test, raw RF calibration yielded Brier=0.0160 and ECE=0.0186; the validation-selected isotonic calibration yielded Brier=0.0148 and ECE=0.0014.

Selective-deferral and collaboration experiments use independently learned Step-6 probabilities rather than the generator's `generated_attack_score`, reducing circular dependence on the benchmark-construction score.

Under the configured oversight assumptions, the strongest observed confidence-gated routing condition used RF raw uncertainty at realized workload 2.14% and produced 0 net errors avoided. This is a controlled benchmark result, not evidence of real analyst performance.